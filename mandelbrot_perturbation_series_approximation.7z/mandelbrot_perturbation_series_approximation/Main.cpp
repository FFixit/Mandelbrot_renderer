#include <iostream>
#include <fstream>
#include "Mandelbrot.h"
#include <limits>
#include <xmmintrin.h>

using namespace std;
using namespace mandelbrot;

int main()
{
	_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
	_mm_setcsr(_mm_getcsr() | 0x8040);


	/*
	mpfr_float xmin("-0.6367543465823899786437398318");
	mpfr_float xmax("-0.6367543465823899786437398320");
	mpfr_float ymin("0.68503129708367730147608783913");
	mpfr_float ymax("0.68503129708367730147608783915");
	*/
	
	/*
 	mpfr_float xmin("-0.9223327810370947027656057193752719757636");
 	mpfr_float xmax("-0.9223327810370947027656057193752719757634");
 	mpfr_float ymin("0.3102598350874576432708737495917724836009");
 	mpfr_float ymax("0.3102598350874576432708737495917724836011");
	*/

	
	/*
	mpfr_float xmin("0.01343887053201212902835491900");
	mpfr_float xmax("0.01343887053201212902837491900");
	mpfr_float ymin("0.65561421876946506225131002766");
	mpfr_float ymax("0.65561421876946506225133002766");
	*/

	/*
	mpfr_float xmin("-0.0056306862431773201255495207714275917884892103802234");
	mpfr_float xmax("0.032253864520761570210093726941663773934633200252854");
	mpfr_float ymin("0.63046253084936263298371639446880296399787487533285");
	mpfr_float ymax("0.66834708161330152331935964218189432972099728596593");
	*/

	
	mpfr_float xmin("0.01343887053201212902736491900");
	mpfr_float xmax("0.01343887053201212902936491900");
	mpfr_float ymin("0.65561421876946506225032002766");
	mpfr_float ymax("0.65561421876946506225232002766");
	

	/*
	mpfr_float xmin = -2.0;
	mpfr_float xmax = 1.0;
	mpfr_float ymin = -1.5;
	mpfr_float ymax = 1.5;
	*/


	Mandelbrot mb(5000, 5000, 70000, xmin, xmax, ymin, ymax);
	mb.createPerturbation();
	mb.saveBitmap(string("mandelbrot"));

	system("pause");
}

